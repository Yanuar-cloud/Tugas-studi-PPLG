<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable = [
        'nis',
        'nama',
        'kelas',
        'jurusan',
        'minat',
    ];

    protected function casts(): array
    {
        return [
            'minat' => 'array',
        ];
    }
}
