<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class StudentController extends Controller
{
    private const INTERESTS = ['Web Developer', 'Game Developer'];

    public function index(): View
    {
        return view('students.index', [
            'students' => Student::query()->orderBy('nama')->get(),
        ]);
    }

    public function create(): View
    {
        return view('students.create', ['student' => new Student()]);
    }

    public function store(Request $request)
    {
        Student::create($request->validate($this->rules(), $this->messages()));

        return redirect()->route('students.index')->with('success', 'Data siswa berhasil ditambahkan.');
    }

    public function edit(Student $student): View
    {
        return view('students.edit', compact('student'));
    }

    public function update(Request $request, Student $student)
    {
        $student->update($request->validate($this->rules($student), $this->messages()));

        return redirect()->route('students.index')->with('success', 'Data siswa berhasil diperbarui.');
    }

    public function destroy(Student $student)
    {
        $student->delete();

        return redirect()->route('students.index')->with('success', 'Data siswa berhasil dihapus.');
    }

    private function rules(?Student $student = null): array
    {
        return [
            'nis' => [
                'required',
                'string',
                'max:20',
                Rule::unique('students', 'nis')->ignore($student),
            ],
            'nama' => ['required', 'string', 'max:100'],
            'kelas' => ['required', Rule::in(['11 RPL'])],
            'jurusan' => ['required', Rule::in(['RPL'])],
            'minat' => ['required', 'array', 'min:1'],
            'minat.*' => ['required', 'string', 'distinct', Rule::in(self::INTERESTS)],
        ];
    }

    private function messages(): array
    {
        return [
            'nis.required' => 'NIS wajib diisi.',
            'nis.unique' => 'NIS tersebut sudah terdaftar.',
            'nama.required' => 'Nama siswa wajib diisi.',
            'kelas.in' => 'Kelas harus 11 RPL.',
            'jurusan.in' => 'Jurusan harus RPL.',
            'minat.required' => 'Pilih setidaknya satu minat pengembangan.',
            'minat.min' => 'Pilih setidaknya satu minat pengembangan.',
            'minat.*.in' => 'Minat yang dipilih tidak tersedia.',
        ];
    }
}
