<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'jadwal')->name('home');

Route::resource('siswa', \App\Http\Controllers\StudentController::class)
    ->except('show')
    ->parameters(['siswa' => 'student'])
    ->names('students');

Route::view('/jadwal', 'jadwal')->name('jadwal');
Route::view('/nilai', 'nilai')->name('nilai');
Route::view('/absensi', 'absensi')->name('absensi');
