@extends('master')

@section('title', 'Ubah Data Siswa')
@section('active_siswa', 'active')

@section('content')
    <p class="eyebrow">Akademik / Data Siswa</p>
    <h1>Ubah Data Siswa</h1>
    <p class="intro">Perbarui informasi untuk {{ $student->nama }}.</p>

    <section class="panel form-panel">
        @include('students._form')
    </section>
@endsection
