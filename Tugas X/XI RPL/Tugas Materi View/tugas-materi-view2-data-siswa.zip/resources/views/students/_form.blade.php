<form action="{{ $student->exists ? route('students.update', $student) : route('students.store') }}" method="POST">
    @csrf
    @if ($student->exists)
        @method('PUT')
    @endif

    <div class="form-grid">
        <div class="field">
            <label for="nis">NIS</label>
            <input id="nis" name="nis" type="text" value="{{ old('nis', $student->nis) }}" maxlength="20" required>
            @error('nis') <span class="error-text">{{ $message }}</span> @enderror
        </div>

        <div class="field">
            <label for="nama">Nama siswa</label>
            <input id="nama" name="nama" type="text" value="{{ old('nama', $student->nama) }}" maxlength="100" required>
            @error('nama') <span class="error-text">{{ $message }}</span> @enderror
        </div>

        <div class="field">
            <label for="kelas">Kelas</label>
            <select id="kelas" name="kelas" required>
                <option value="11 RPL" @selected(old('kelas', $student->kelas ?: '11 RPL') === '11 RPL')>11 RPL</option>
            </select>
            @error('kelas') <span class="error-text">{{ $message }}</span> @enderror
        </div>

        <div class="field">
            <label for="jurusan">Jurusan</label>
            <select id="jurusan" name="jurusan" required>
                <option value="RPL" @selected(old('jurusan', $student->jurusan ?: 'RPL') === 'RPL')>RPL</option>
            </select>
            @error('jurusan') <span class="error-text">{{ $message }}</span> @enderror
        </div>

        <fieldset class="field full" style="margin:0;padding:0;border:0">
            <legend class="field-label" style="margin-bottom:8px">Minat pengembangan</legend>
            <div class="checkbox-list">
                @foreach (['Web Developer', 'Game Developer'] as $interest)
                    <label class="checkbox-option">
                        <input type="checkbox" name="minat[]" value="{{ $interest }}" @checked(in_array($interest, old('minat', $student->minat ?? []), true))>
                        {{ $interest }}
                    </label>
                @endforeach
            </div>
            @error('minat') <span class="error-text">{{ $message }}</span> @enderror
            @error('minat.*') <span class="error-text">{{ $message }}</span> @enderror
        </fieldset>
    </div>

    <div class="form-actions">
        <button class="button" type="submit">{{ $student->exists ? 'Simpan Perubahan' : 'Simpan Siswa' }}</button>
        <a class="button secondary" href="{{ route('students.index') }}">Batal</a>
    </div>
</form>
