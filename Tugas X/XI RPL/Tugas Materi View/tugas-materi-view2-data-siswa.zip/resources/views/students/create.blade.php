@extends('master')

@section('title', 'Tambah Siswa')
@section('active_siswa', 'active')

@section('content')
    <p class="eyebrow">Akademik / Data Siswa</p>
    <h1>Tambah Siswa</h1>
    <p class="intro">Isi identitas dan pilih minat pengembangan siswa.</p>

    <section class="panel form-panel">
        @include('students._form')
    </section>
@endsection
