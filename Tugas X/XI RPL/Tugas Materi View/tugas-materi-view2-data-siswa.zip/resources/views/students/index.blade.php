@extends('master')

@section('title', 'Data Siswa')
@section('active_siswa', 'active')

@section('content')
    <p class="eyebrow">Akademik / Data Siswa</p>
    <h1>Data Siswa</h1>
    <p class="intro">Kelola data siswa kelas 11 RPL dan pilihan minat pengembangan.</p>

    @if (session('success'))
        <div class="alert" role="status">{{ session('success') }}</div>
    @endif

    <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:20px">
        <p style="margin:0;color:#64748b;font-size:14px">{{ $students->count() }} siswa terdaftar</p>
        <a class="button" href="{{ route('students.create') }}">+ Tambah Siswa</a>
    </div>

    <section class="panel" aria-labelledby="students-heading">
        <div class="panel-heading">
            <h2 id="students-heading">Daftar siswa</h2>
            <p>Kelas XI RPL · Jurusan Rekayasa Perangkat Lunak</p>
        </div>
        @if ($students->isEmpty())
            <div class="empty-state">Belum ada data siswa. Pilih “Tambah Siswa” untuk mengisi data pertama.</div>
        @else
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr><th>NIS</th><th>Nama</th><th>Kelas</th><th>Jurusan</th><th>Minat</th><th>Aksi</th></tr>
                    </thead>
                    <tbody>
                        @foreach ($students as $student)
                            <tr>
                                <td>{{ $student->nis }}</td>
                                <td>{{ $student->nama }}</td>
                                <td>{{ $student->kelas }}</td>
                                <td>{{ $student->jurusan }}</td>
                                <td>
                                    @foreach ($student->minat as $interest)
                                        <span class="badge blue">{{ $interest }}</span>
                                    @endforeach
                                </td>
                                <td>
                                    <div class="actions">
                                        <a class="button secondary" href="{{ route('students.edit', $student) }}">Ubah</a>
                                        <form class="inline-form" action="{{ route('students.destroy', $student) }}" method="POST" onsubmit="return confirm('Hapus data siswa ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button class="button danger" type="submit">Hapus</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </section>
@endsection
