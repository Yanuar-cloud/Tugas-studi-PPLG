<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') | Tugas Materi View 1</title>
    <style>
        :root {
            color-scheme: light;
            font-family: "Segoe UI", Arial, sans-serif;
            color: #172033;
            background: #f3f6fb;
        }

        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; }
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            padding: 20px max(24px, calc((100% - 1120px) / 2));
            color: white;
            background: #172554;
        }
        .brand { font-size: 19px; font-weight: 700; letter-spacing: .2px; }
        .brand small { display: block; margin-top: 4px; color: #bfdbfe; font-size: 12px; font-weight: 400; }
        nav { display: flex; flex-wrap: wrap; gap: 8px; }
        .nav-link {
            padding: 10px 15px;
            border-radius: 8px;
            color: #dbeafe;
            font-size: 14px;
            text-decoration: none;
        }
        .nav-link:hover, .nav-link.active { color: #172554; background: white; }
        main { width: min(1120px, calc(100% - 40px)); margin: 42px auto; }
        .eyebrow { margin: 0 0 8px; color: #2563eb; font-size: 12px; font-weight: 700; letter-spacing: 1.2px; text-transform: uppercase; }
        h1 { margin: 0; font-size: clamp(28px, 4vw, 36px); }
        .intro { margin: 10px 0 28px; color: #64748b; }
        .panel {
            overflow: hidden;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            background: white;
            box-shadow: 0 10px 30px rgb(15 23 42 / 5%);
        }
        .panel-heading { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; }
        .panel-heading h2 { margin: 0; font-size: 17px; }
        .panel-heading p { margin: 6px 0 0; color: #64748b; font-size: 13px; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th, td { padding: 15px 24px; border-bottom: 1px solid #edf1f6; white-space: nowrap; }
        th { color: #64748b; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; }
        td { font-size: 14px; }
        tbody tr:last-child td { border-bottom: 0; }
        .badge { display: inline-block; padding: 5px 10px; border-radius: 999px; color: #166534; background: #dcfce7; font-size: 12px; font-weight: 600; }
        .badge.blue { color: #1d4ed8; background: #dbeafe; }
        .badge.amber { color: #92400e; background: #fef3c7; }
        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 10px 15px;
            border: 0;
            border-radius: 8px;
            color: white;
            background: #2563eb;
            font: inherit;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
        }
        .button:hover { background: #1d4ed8; }
        .button.secondary { color: #334155; background: #e2e8f0; }
        .button.secondary:hover { background: #cbd5e1; }
        .button.danger { padding: 8px 11px; background: #dc2626; }
        .button.danger:hover { background: #b91c1c; }
        .form-panel { max-width: 720px; padding: 24px; }
        .form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
        .field { display: grid; gap: 7px; }
        .field.full { grid-column: 1 / -1; }
        .field label, .field-label { color: #334155; font-size: 14px; font-weight: 600; }
        .field input, .field select {
            width: 100%;
            min-height: 42px;
            padding: 9px 11px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            color: #172033;
            background: white;
            font: inherit;
            font-size: 14px;
        }
        .field input:focus, .field select:focus { border-color: #2563eb; outline: 3px solid #dbeafe; }
        .checkbox-list { display: flex; flex-wrap: wrap; gap: 12px; }
        .checkbox-option { display: inline-flex; align-items: center; gap: 8px; padding: 10px 12px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 14px; }
        .checkbox-option input { width: 16px; height: 16px; accent-color: #2563eb; }
        .error-text { color: #b91c1c; font-size: 13px; }
        .alert { margin-bottom: 20px; padding: 13px 16px; border-radius: 9px; color: #166534; background: #dcfce7; font-size: 14px; }
        .form-actions { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 24px; }
        .actions { display: flex; align-items: center; gap: 8px; }
        .inline-form { display: inline; }
        .empty-state { padding: 32px 24px; color: #64748b; text-align: center; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 16px; margin-bottom: 22px; }
        .summary-card { padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; background: white; }
        .summary-card span { display: block; color: #64748b; font-size: 13px; }
        .summary-card strong { display: block; margin-top: 8px; font-size: 27px; }
        footer { padding: 20px; color: #94a3b8; font-size: 12px; text-align: center; }
        @media (max-width: 640px) {
            header { align-items: flex-start; flex-direction: column; padding: 18px 20px; }
            nav { width: 100%; }
            .nav-link { padding: 9px 12px; }
            main { margin-top: 30px; }
            th, td { padding: 13px 16px; }
            .form-grid { grid-template-columns: 1fr; }
            .field.full { grid-column: auto; }
        }
    </style>
</head>
<body>
    <header>
        <div class="brand">
            Ruang Siswa
            <small>Portal informasi akademik</small>
        </div>
        <nav aria-label="Navigasi utama">
            <a class="nav-link @yield('active_jadwal')" href="{{ route('jadwal') }}">Jadwal</a>
            <a class="nav-link @yield('active_nilai')" href="{{ route('nilai') }}">Nilai</a>
            <a class="nav-link @yield('active_absensi')" href="{{ route('absensi') }}">Absensi</a>
            <a class="nav-link @yield('active_siswa')" href="{{ route('students.index') }}">Data Siswa</a>
        </nav>
    </header>

    <main>
        @yield('content')
    </main>

    <footer>© 2026 Ruang Siswa · Tugas Materi View 1</footer>
</body>
</html>
