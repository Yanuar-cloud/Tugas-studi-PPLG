<?php

namespace Tests\Feature;

use App\Models\Student;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class StudentCrudTest extends TestCase
{
    use RefreshDatabase;

    public function test_student_can_be_created_updated_and_deleted(): void
    {
        $studentData = [
            'nis' => '1126002',
            'nama' => 'Bima Pratama',
            'kelas' => '11 RPL',
            'jurusan' => 'RPL',
            'minat' => ['Web Developer', 'Game Developer'],
        ];

        $this->post(route('students.store'), $studentData)
            ->assertRedirect(route('students.index'));

        $student = Student::where('nis', '1126002')->firstOrFail();
        $this->assertSame(['Web Developer', 'Game Developer'], $student->minat);

        $this->put(route('students.update', $student), [
            ...$studentData,
            'nama' => 'Bima Wijaya',
            'minat' => ['Game Developer'],
        ])->assertRedirect(route('students.index'));

        $this->assertDatabaseHas('students', [
            'id' => $student->id,
            'nama' => 'Bima Wijaya',
            'minat' => '["Game Developer"]',
        ]);

        $this->delete(route('students.destroy', $student))
            ->assertRedirect(route('students.index'));

        $this->assertDatabaseMissing('students', ['id' => $student->id]);
    }

    public function test_student_class_and_interests_are_validated(): void
    {
        $this->from(route('students.create'))
            ->post(route('students.store'), [
                'nis' => '1126003',
                'nama' => 'Citra',
                'kelas' => '12 RPL',
                'jurusan' => 'RPL',
                'minat' => ['Web Developer'],
            ])
            ->assertSessionHasErrors('kelas');

        $this->assertDatabaseCount('students', 0);
    }

    public function test_student_list_and_form_pages_render(): void
    {
        $student = Student::create([
            'nis' => '1126001',
            'nama' => 'Alya Putri',
            'kelas' => '11 RPL',
            'jurusan' => 'RPL',
            'minat' => ['Web Developer', 'Game Developer'],
        ]);

        $this->get(route('students.index'))
            ->assertOk()
            ->assertSee('Alya Putri')
            ->assertSee('Game Developer');

        $this->get(route('students.create'))
            ->assertOk()
            ->assertSee('Tambah Siswa');

        $this->get(route('students.edit', $student))
            ->assertOk()
            ->assertSee('Alya Putri');
    }
}
