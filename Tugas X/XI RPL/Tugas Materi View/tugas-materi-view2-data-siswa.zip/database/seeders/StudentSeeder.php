<?php

namespace Database\Seeders;

use App\Models\Student;
use Illuminate\Database\Seeder;

class StudentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Student::updateOrCreate(
            ['nis' => '1126001'],
            [
                'nama' => 'Alya Putri',
                'kelas' => '11 RPL',
                'jurusan' => 'RPL',
                'minat' => ['Web Developer', 'Game Developer'],
            ],
        );
    }
}
