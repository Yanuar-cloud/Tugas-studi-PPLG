@extends('master')

@section('title', 'Jadwal Pelajaran')
@section('active_jadwal', 'active')

@section('content')
    <p class="eyebrow">Akademik / Jadwal</p>
    <h1>Jadwal Pelajaran</h1>
    <p class="intro">Jadwal kegiatan belajar untuk kelas XI RPL A.</p>

    <section class="panel" aria-labelledby="schedule-heading">
        <div class="panel-heading">
            <h2 id="schedule-heading">Minggu, 24–28 November 2026</h2>
            <p>Semester ganjil · Tahun ajaran 2026/2027</p>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Hari</th><th>Waktu</th><th>Mata Pelajaran</th><th>Pengajar</th><th>Ruang</th></tr>
                </thead>
                <tbody>
                    <tr><td>Senin</td><td>08.00–09.30</td><td>Pemrograman Web</td><td>Bu Rina</td><td>Lab 1</td></tr>
                    <tr><td>Selasa</td><td>10.00–11.30</td><td>Basis Data</td><td>Pak Dedi</td><td>Lab 2</td></tr>
                    <tr><td>Rabu</td><td>08.00–09.30</td><td>Desain UI/UX</td><td>Bu Maya</td><td>Ruang 203</td></tr>
                    <tr><td>Kamis</td><td>13.00–14.30</td><td>Rekayasa Perangkat Lunak</td><td>Pak Arif</td><td>Ruang 205</td></tr>
                    <tr><td>Jumat</td><td>09.00–10.30</td><td>Bahasa Inggris</td><td>Bu Sari</td><td>Ruang 201</td></tr>
                </tbody>
            </table>
        </div>
    </section>
@endsection
