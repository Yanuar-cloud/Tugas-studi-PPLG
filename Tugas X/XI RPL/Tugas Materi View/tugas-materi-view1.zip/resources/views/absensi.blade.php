@extends('master')

@section('title', 'Rekap Absensi')
@section('active_absensi', 'active')

@section('content')
    <p class="eyebrow">Akademik / Absensi</p>
    <h1>Rekap Absensi</h1>
    <p class="intro">Catatan kehadiran kelas XI RPL A untuk semester ganjil.</p>

    <div class="summary">
        <div class="summary-card"><span>Persentase kehadiran</span><strong>96%</strong></div>
        <div class="summary-card"><span>Hadir</span><strong>48 hari</strong></div>
        <div class="summary-card"><span>Izin / sakit / alpa</span><strong>2 / 0 / 0</strong></div>
    </div>

    <section class="panel" aria-labelledby="attendance-heading">
        <div class="panel-heading">
            <h2 id="attendance-heading">Riwayat kehadiran</h2>
            <p>Rekap minggu terakhir</p>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Tanggal</th><th>Hari</th><th>Status</th><th>Waktu masuk</th><th>Catatan</th></tr>
                </thead>
                <tbody>
                    <tr><td>24 Nov 2026</td><td>Senin</td><td><span class="badge">Hadir</span></td><td>07.42</td><td>—</td></tr>
                    <tr><td>25 Nov 2026</td><td>Selasa</td><td><span class="badge">Hadir</span></td><td>07.48</td><td>—</td></tr>
                    <tr><td>26 Nov 2026</td><td>Rabu</td><td><span class="badge amber">Izin</span></td><td>—</td><td>Keperluan keluarga</td></tr>
                    <tr><td>27 Nov 2026</td><td>Kamis</td><td><span class="badge">Hadir</span></td><td>07.39</td><td>—</td></tr>
                    <tr><td>28 Nov 2026</td><td>Jumat</td><td><span class="badge">Hadir</span></td><td>07.45</td><td>—</td></tr>
                </tbody>
            </table>
        </div>
    </section>
@endsection
