@extends('master')

@section('title', 'Nilai Akademik')
@section('active_nilai', 'active')

@section('content')
    <p class="eyebrow">Akademik / Nilai</p>
    <h1>Nilai Akademik</h1>
    <p class="intro">Ringkasan hasil belajar semester ganjil kelas XI RPL A.</p>

    <div class="summary">
        <div class="summary-card"><span>Rata-rata nilai</span><strong>87,5</strong></div>
        <div class="summary-card"><span>Mata pelajaran</span><strong>4</strong></div>
        <div class="summary-card"><span>Predikat tertinggi</span><strong>A</strong></div>
    </div>

    <section class="panel" aria-labelledby="grades-heading">
        <div class="panel-heading">
            <h2 id="grades-heading">Hasil belajar</h2>
            <p>Nilai akhir sementara semester ganjil</p>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Mata Pelajaran</th><th>Tugas</th><th>UTS</th><th>UAS</th><th>Nilai Akhir</th><th>Predikat</th></tr>
                </thead>
                <tbody>
                    <tr><td>Pemrograman Web</td><td>90</td><td>88</td><td>92</td><td>90</td><td><span class="badge">A</span></td></tr>
                    <tr><td>Basis Data</td><td>85</td><td>87</td><td>89</td><td>87</td><td><span class="badge blue">B</span></td></tr>
                    <tr><td>Desain UI/UX</td><td>92</td><td>90</td><td>94</td><td>92</td><td><span class="badge">A</span></td></tr>
                    <tr><td>Rekayasa Perangkat Lunak</td><td>80</td><td>84</td><td>85</td><td>81</td><td><span class="badge blue">B</span></td></tr>
                </tbody>
            </table>
        </div>
    </section>
@endsection
