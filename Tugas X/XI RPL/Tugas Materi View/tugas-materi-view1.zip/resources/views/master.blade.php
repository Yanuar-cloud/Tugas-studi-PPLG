<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') | Tugas Materi View 1</title>
    <style>
        :root {
            color-scheme: light;
            font-family: "Segoe UI", Arial, sans-serif;
            color: #172033;
            background: #f3f6fb;
        }

        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; }
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            padding: 20px max(24px, calc((100% - 1120px) / 2));
            color: white;
            background: #172554;
        }
        .brand { font-size: 19px; font-weight: 700; letter-spacing: .2px; }
        .brand small { display: block; margin-top: 4px; color: #bfdbfe; font-size: 12px; font-weight: 400; }
        nav { display: flex; flex-wrap: wrap; gap: 8px; }
        .nav-link {
            padding: 10px 15px;
            border-radius: 8px;
            color: #dbeafe;
            font-size: 14px;
            text-decoration: none;
        }
        .nav-link:hover, .nav-link.active { color: #172554; background: white; }
        main { width: min(1120px, calc(100% - 40px)); margin: 42px auto; }
        .eyebrow { margin: 0 0 8px; color: #2563eb; font-size: 12px; font-weight: 700; letter-spacing: 1.2px; text-transform: uppercase; }
        h1 { margin: 0; font-size: clamp(28px, 4vw, 36px); }
        .intro { margin: 10px 0 28px; color: #64748b; }
        .panel {
            overflow: hidden;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            background: white;
            box-shadow: 0 10px 30px rgb(15 23 42 / 5%);
        }
        .panel-heading { padding: 20px 24px; border-bottom: 1px solid #e2e8f0; }
        .panel-heading h2 { margin: 0; font-size: 17px; }
        .panel-heading p { margin: 6px 0 0; color: #64748b; font-size: 13px; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th, td { padding: 15px 24px; border-bottom: 1px solid #edf1f6; white-space: nowrap; }
        th { color: #64748b; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .5px; }
        td { font-size: 14px; }
        tbody tr:last-child td { border-bottom: 0; }
        .badge { display: inline-block; padding: 5px 10px; border-radius: 999px; color: #166534; background: #dcfce7; font-size: 12px; font-weight: 600; }
        .badge.blue { color: #1d4ed8; background: #dbeafe; }
        .badge.amber { color: #92400e; background: #fef3c7; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 16px; margin-bottom: 22px; }
        .summary-card { padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; background: white; }
        .summary-card span { display: block; color: #64748b; font-size: 13px; }
        .summary-card strong { display: block; margin-top: 8px; font-size: 27px; }
        footer { padding: 20px; color: #94a3b8; font-size: 12px; text-align: center; }
        @media (max-width: 640px) {
            header { align-items: flex-start; flex-direction: column; padding: 18px 20px; }
            nav { width: 100%; }
            .nav-link { padding: 9px 12px; }
            main { margin-top: 30px; }
            th, td { padding: 13px 16px; }
        }
    </style>
</head>
<body>
    <header>
        <div class="brand">
            Ruang Siswa
            <small>Portal informasi akademik</small>
        </div>
        <nav aria-label="Navigasi utama">
            <a class="nav-link @yield('active_jadwal')" href="{{ route('jadwal') }}">Jadwal</a>
            <a class="nav-link @yield('active_nilai')" href="{{ route('nilai') }}">Nilai</a>
            <a class="nav-link @yield('active_absensi')" href="{{ route('absensi') }}">Absensi</a>
        </nav>
    </header>

    <main>
        @yield('content')
    </main>

    <footer>© 2026 Ruang Siswa · Tugas Materi View 1</footer>
</body>
</html>
