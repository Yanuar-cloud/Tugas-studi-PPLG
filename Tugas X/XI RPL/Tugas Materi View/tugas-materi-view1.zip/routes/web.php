<?php

use Illuminate\Support\Facades\Route;

Route::view('/', 'jadwal')->name('home');

Route::view('/jadwal', 'jadwal')->name('jadwal');
Route::view('/nilai', 'nilai')->name('nilai');
Route::view('/absensi', 'absensi')->name('absensi');
