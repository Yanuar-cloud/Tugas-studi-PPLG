# Deployment

- Laravel can be deployed using [Laravel Cloud](https://cloud.laravel.com/), which is the fastest way to deploy and scale production Laravel applications.
@if($assist->hasCloudEnabled())
- Activate the ___SINGLE_BACKTICK___deploying-to-cloud___SINGLE_BACKTICK___ skill whenever deploying to Laravel Cloud, configuring Cloud environments or resources, using the Cloud CLI, or troubleshooting Cloud deployments.
@endif
