@extends('layouts.store')

@section('title', 'Masuk')

@section('content')
<main class="login-shell">
    <section class="login-story">
        <a class="brand" href="{{ route('login') }}">
            <span class="brand-mark">TK</span>
            <span>Toko Kita</span>
        </a>
        <div class="story-copy">
            <span class="eyebrow">Ruang kerja pemilik toko</span>
            <h1>Semua stok, dalam kendali.</h1>
            <p>Masuk untuk melihat ringkasan persediaan dan aktivitas toko hari ini.</p>
        </div>
        <div class="story-foot">Sederhana untuk dikelola. Siap untuk berkembang.</div>
    </section>

    <section class="login-panel">
        <div class="login-card">
            <span class="eyebrow">Selamat datang kembali</span>
            <h2>Masuk ke akun</h2>
            <p class="subcopy">Gunakan akun demo untuk membuka dashboard Toko Kita.</p>

            @if (session('status'))
                <div class="status-message">{{ session('status') }}</div>
            @endif

            @if ($errors->any())
                <div class="form-error" role="alert">
                    @foreach ($errors->all() as $error)
                        <div>{{ $error }}</div>
                    @endforeach
                </div>
            @endif

            <form method="POST" action="{{ route('login.store') }}">
                @csrf
                <div class="field">
                    <label for="email">Email</label>
                    <input id="email" name="email" type="email" value="{{ old('email') }}" placeholder="nama@tokokita.test" autocomplete="username" required autofocus>
                </div>
                <div class="field">
                    <label for="password">Kata sandi</label>
                    <input id="password" name="password" type="password" placeholder="Masukkan kata sandi" autocomplete="current-password" required>
                </div>
                <label class="remember-row">
                    <input type="checkbox" name="remember" value="1">
                    <span>Ingat saya di perangkat ini</span>
                </label>
                <button class="button" type="submit">Masuk ke dashboard</button>
            </form>

            <div class="demo-note">
                Akun demo<br>
                <strong>Email:</strong> admin@tokokita.test<br>
                <strong>Kata sandi:</strong> Toko123!
            </div>
        </div>
    </section>
</main>
@endsection
