<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Toko Kita') | Toko Kita</title>
    <style>
        :root {
            color-scheme: light;
            --ink: #18251f;
            --muted: #748078;
            --green: #1d7655;
            --green-dark: #15583f;
            --mint: #e6f4eb;
            --line: #e8eee9;
            --paper: #ffffff;
            --background: #f5f8f5;
            --orange: #e99b54;
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; color: var(--ink); background: var(--background); }
        a { color: inherit; text-decoration: none; }
        button, input { font: inherit; }
        .brand { display: inline-flex; align-items: center; gap: 11px; font-size: 17px; font-weight: 800; letter-spacing: -.5px; }
        .brand-mark { display: grid; width: 39px; height: 39px; place-items: center; border-radius: 13px; color: white; background: var(--green); font-size: 12px; letter-spacing: .5px; }
        .eyebrow { color: var(--green); font-size: 11px; font-weight: 800; letter-spacing: 1.7px; text-transform: uppercase; }
        .login-shell { display: grid; min-height: 100vh; grid-template-columns: minmax(0, 1fr) minmax(400px, .82fr); padding: 22px; gap: 22px; }
        .login-story { position: relative; display: flex; min-height: 650px; flex-direction: column; justify-content: space-between; overflow: hidden; padding: 42px; border-radius: 27px; color: white; background: #193e31; }
        .login-story:before, .login-story:after { position: absolute; content: ""; border: 1px solid rgba(255,255,255,.1); border-radius: 50%; pointer-events: none; }
        .login-story:before { width: 500px; height: 500px; right: -155px; bottom: -180px; }
        .login-story:after { width: 340px; height: 340px; right: -75px; bottom: -98px; }
        .login-story .brand-mark { color: var(--green-dark); background: #c9ef9c; }
        .story-copy { position: relative; z-index: 1; max-width: 550px; margin: auto 0; padding: 45px 0; }
        .story-copy .eyebrow { color: #b6e68a; }
        .story-copy h1 { max-width: 520px; margin: 18px 0; font-size: clamp(42px, 5vw, 68px); line-height: 1.02; letter-spacing: -3.4px; }
        .story-copy p { max-width: 410px; color: #d3e2d9; font-size: 16px; line-height: 1.8; }
        .story-foot { position: relative; z-index: 1; color: #c5d8cc; font-size: 12px; }
        .login-panel { display: grid; place-items: center; padding: 32px; }
        .login-card { width: min(100%, 430px); padding: 24px 0; }
        .login-card h2 { margin: 12px 0 8px; font-size: 32px; letter-spacing: -1.2px; }
        .subcopy { margin: 0 0 32px; color: var(--muted); line-height: 1.65; }
        .field { margin: 18px 0; }
        .field label { display: block; margin-bottom: 8px; font-size: 13px; font-weight: 700; }
        .field input { width: 100%; padding: 13px 15px; border: 1px solid #dfe7e1; border-radius: 11px; outline: none; background: white; }
        .field input:focus { border-color: var(--green); box-shadow: 0 0 0 3px rgba(29,118,85,.11); }
        .remember-row { display: flex; align-items: center; gap: 9px; margin: 17px 0 22px; color: var(--muted); font-size: 13px; }
        .remember-row input { accent-color: var(--green); }
        .button { display: inline-flex; width: 100%; min-height: 48px; align-items: center; justify-content: center; border: 0; border-radius: 11px; color: white; background: var(--green); cursor: pointer; font-weight: 750; transition: background .15s, transform .15s; }
        .button:hover { transform: translateY(-1px); background: var(--green-dark); }
        .form-error, .status-message { margin: 0 0 18px; padding: 12px 14px; border-radius: 10px; font-size: 13px; line-height: 1.5; }
        .form-error { color: #9c3939; background: #fff0ef; }
        .status-message { color: #255a40; background: var(--mint); }
        .demo-note { margin-top: 25px; padding: 15px; border: 1px solid var(--line); border-radius: 12px; color: var(--muted); font-size: 12px; line-height: 1.8; }
        .demo-note strong { color: var(--ink); }
        .dashboard { max-width: 1240px; margin: 0 auto; padding: 30px 34px 55px; }
        .topbar { display: flex; min-height: 66px; align-items: center; justify-content: space-between; margin-bottom: 35px; }
        .topbar-right { display: flex; align-items: center; gap: 19px; }
        .user-chip { display: flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 700; }
        .avatar { display: grid; width: 37px; height: 37px; place-items: center; border-radius: 50%; color: var(--green-dark); background: #d8efdf; font-size: 13px; }
        .logout-form { margin: 0; }
        .logout-button { padding: 9px 13px; border: 1px solid #dbe5dd; border-radius: 9px; color: #435149; background: white; cursor: pointer; font-size: 12px; font-weight: 700; }
        .welcome { display: flex; align-items: end; justify-content: space-between; gap: 18px; margin-bottom: 27px; }
        .welcome h1 { margin: 8px 0 7px; font-size: clamp(29px, 4vw, 39px); letter-spacing: -1.5px; }
        .welcome p { margin: 0; color: var(--muted); font-size: 14px; }
        .date-pill { padding: 10px 13px; border: 1px solid var(--line); border-radius: 10px; color: #54635a; background: white; font-size: 12px; }
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 24px; }
        .stat-card { padding: 20px; border: 1px solid var(--line); border-radius: 15px; background: var(--paper); }
        .stat-top { display: flex; align-items: center; justify-content: space-between; color: var(--muted); font-size: 12px; font-weight: 650; }
        .stat-icon { display: grid; width: 34px; height: 34px; place-items: center; border-radius: 10px; color: var(--green); background: var(--mint); font-weight: 800; }
        .stat-number { margin-top: 18px; font-size: 27px; font-weight: 800; letter-spacing: -.8px; }
        .stat-hint { margin-top: 5px; color: var(--muted); font-size: 11px; }
        .inventory { overflow: hidden; border: 1px solid var(--line); border-radius: 16px; background: white; }
        .inventory-heading { display: flex; align-items: center; justify-content: space-between; padding: 20px 22px; border-bottom: 1px solid var(--line); }
        .inventory-heading h2 { margin: 0 0 5px; font-size: 17px; letter-spacing: -.3px; }
        .inventory-heading p { margin: 0; color: var(--muted); font-size: 12px; }
        .live-badge { padding: 7px 10px; border-radius: 20px; color: var(--green); background: var(--mint); font-size: 11px; font-weight: 750; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { padding: 12px 22px; color: #859087; background: #fbfcfb; font-size: 10px; letter-spacing: .8px; text-transform: uppercase; }
        td { padding: 15px 22px; border-top: 1px solid #f0f3f0; font-size: 13px; }
        .product-name { font-weight: 750; }
        .sku { margin-top: 4px; color: #89938c; font-size: 11px; }
        .category-pill { padding: 6px 9px; border-radius: 7px; color: #5a685f; background: #f1f5f1; font-size: 11px; }
        .stock-value { font-weight: 750; }
        .stock-low { color: #a45b28; }
        .empty-row { padding: 30px; color: var(--muted); text-align: center; }
        @media (max-width: 800px) {
            .login-shell { grid-template-columns: 1fr; padding: 12px; }
            .login-story { min-height: 360px; padding: 27px; }
            .story-copy { padding: 36px 0; }
            .story-copy h1 { font-size: 43px; }
            .login-panel { padding: 22px; }
            .dashboard { padding: 20px 16px 40px; }
            .stats-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 520px) {
            .topbar { align-items: flex-start; }
            .topbar-right { gap: 9px; }
            .user-chip span:last-child { display: none; }
            .welcome { align-items: flex-start; flex-direction: column; }
            .inventory-heading { align-items: flex-start; gap: 12px; }
            th, td { padding-right: 14px; padding-left: 14px; }
        }
    </style>
</head>
<body>
    @yield('content')
</body>
</html>
