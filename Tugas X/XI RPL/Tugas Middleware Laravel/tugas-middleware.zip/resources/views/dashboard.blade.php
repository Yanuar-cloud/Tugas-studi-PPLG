@extends('layouts.store')

@section('title', 'Dashboard')

@section('content')
<main class="dashboard">
    <header class="topbar">
        <a class="brand" href="{{ route('dashboard') }}">
            <span class="brand-mark">TK</span>
            <span>Toko Kita</span>
        </a>
        <div class="topbar-right">
            <div class="user-chip">
                <span class="avatar">{{ strtoupper(substr($user->name, 0, 1)) }}</span>
                <span>{{ $user->name }}</span>
            </div>
            <form class="logout-form" method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="logout-button" type="submit">Keluar</button>
            </form>
        </div>
    </header>

    <section class="welcome">
        <div>
            <span class="eyebrow">Ringkasan toko</span>
            <h1>Halo, {{ $user->name }}!</h1>
            <p>Berikut gambaran persediaan tokomu saat ini.</p>
        </div>
        <div class="date-pill">{{ now()->locale('id')->translatedFormat('l, d F Y') }}</div>
    </section>

    <section class="stats-grid" aria-label="Statistik toko">
        <article class="stat-card">
            <div class="stat-top"><span>Jenis produk</span><span class="stat-icon">P</span></div>
            <div class="stat-number">{{ $productCount }}</div>
            <div class="stat-hint">Produk tercatat di katalog</div>
        </article>
        <article class="stat-card">
            <div class="stat-top"><span>Total unit stok</span><span class="stat-icon">S</span></div>
            <div class="stat-number">{{ number_format($stockCount, 0, ',', '.') }}</div>
            <div class="stat-hint">Unit siap dijual</div>
        </article>
        <article class="stat-card">
            <div class="stat-top"><span>Nilai persediaan</span><span class="stat-icon">Rp</span></div>
            <div class="stat-number">Rp {{ number_format($inventoryValue, 0, ',', '.') }}</div>
            <div class="stat-hint">Perkiraan nilai seluruh stok</div>
        </article>
    </section>

    <section class="inventory">
        <div class="inventory-heading">
            <div>
                <h2>Daftar persediaan</h2>
                <p>Contoh data produk yang tersimpan di database.</p>
            </div>
            <span class="live-badge">Data aktif</span>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($products as $product)
                        <tr>
                            <td>
                                <div class="product-name">{{ $product->name }}</div>
                                <div class="sku">{{ $product->sku }}</div>
                            </td>
                            <td><span class="category-pill">{{ $product->category }}</span></td>
                            <td>Rp {{ number_format((float) $product->price, 0, ',', '.') }}</td>
                            <td class="stock-value {{ $product->stock < 15 ? 'stock-low' : '' }}">{{ $product->stock }} unit</td>
                        </tr>
                    @empty
                        <tr><td class="empty-row" colspan="4">Belum ada produk yang terdaftar.</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </section>
</main>
@endsection
