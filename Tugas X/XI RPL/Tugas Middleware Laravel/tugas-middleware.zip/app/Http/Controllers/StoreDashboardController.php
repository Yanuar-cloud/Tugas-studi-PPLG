<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;

class StoreDashboardController extends Controller
{
    public function __invoke(): View
    {
        $products = Product::query()->orderBy('name')->get();

        return view('dashboard', [
            'user' => Auth::user(),
            'products' => $products,
            'productCount' => $products->count(),
            'stockCount' => $products->sum('stock'),
            'inventoryValue' => $products->sum(
                fn (Product $product): float => (float) $product->price * $product->stock,
            ),
        ]);
    }
}
