<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => 'admin@tokokita.test'],
            [
                'name' => 'Admin Toko',
                'password' => 'Toko123!',
            ],
        );

        $products = [
            ['sku' => 'ATK-001', 'name' => 'Buku Catatan A5', 'category' => 'Alat Tulis', 'price' => 18000, 'stock' => 42],
            ['sku' => 'ATK-002', 'name' => 'Pulpen Gel Hitam', 'category' => 'Alat Tulis', 'price' => 9500, 'stock' => 76],
            ['sku' => 'ELE-001', 'name' => 'Lampu Meja Mini', 'category' => 'Elektronik', 'price' => 125000, 'stock' => 12],
            ['sku' => 'HOM-001', 'name' => 'Botol Minum 600 ml', 'category' => 'Perlengkapan', 'price' => 54000, 'stock' => 28],
            ['sku' => 'BAG-001', 'name' => 'Tas Belanja Kanvas', 'category' => 'Tas', 'price' => 39000, 'stock' => 19],
        ];

        foreach ($products as $product) {
            Product::updateOrCreate(
                ['sku' => $product['sku']],
                $product,
            );
        }
    }
}
