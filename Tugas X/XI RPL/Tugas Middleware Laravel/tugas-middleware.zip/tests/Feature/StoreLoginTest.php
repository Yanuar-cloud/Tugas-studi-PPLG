<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class StoreLoginTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_is_redirected_by_store_middleware(): void
    {
        $this->get(route('dashboard'))
            ->assertRedirect(route('login'));
    }

    public function test_valid_login_starts_session_and_opens_store_dashboard(): void
    {
        $user = User::factory()->create([
            'email' => 'owner@example.test',
            'password' => 'correct-password',
        ]);
        Product::create([
            'name' => 'Buku Catatan A5',
            'sku' => 'ATK-001',
            'category' => 'Alat Tulis',
            'price' => 18000,
            'stock' => 42,
        ]);

        $this->post(route('login.store'), [
            'email' => 'owner@example.test',
            'password' => 'correct-password',
        ])->assertRedirect(route('dashboard'));

        $this->assertAuthenticatedAs($user);
        $this->get(route('dashboard'))
            ->assertOk()
            ->assertSee('Buku Catatan A5')
            ->assertSee('Halo, '.$user->name);
    }

    public function test_invalid_login_does_not_create_authenticated_session(): void
    {
        User::factory()->create([
            'email' => 'owner@example.test',
            'password' => 'correct-password',
        ]);

        $this->from(route('login'))
            ->post(route('login.store'), [
                'email' => 'owner@example.test',
                'password' => 'wrong-password',
            ])
            ->assertRedirect(route('login'))
            ->assertSessionHasErrors('email');

        $this->assertGuest();
    }

    public function test_logout_invalidates_access_to_protected_dashboard(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)
            ->post(route('logout'))
            ->assertRedirect(route('login'));

        $this->assertGuest();
        $this->get(route('dashboard'))
            ->assertRedirect(route('login'));
    }
}
