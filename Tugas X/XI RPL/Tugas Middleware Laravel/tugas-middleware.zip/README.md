# Tugas Middleware — Toko Kita

Aplikasi latihan login berbasis session untuk tema toko. Route dashboard dan logout dilindungi middleware `store.auth`.

## Bagian utama

- `LoginController` memeriksa kredensial dan mengelola session masuk/keluar.
- `EnsureStoreLogin` memeriksa status login sebelum route dashboard dibuka.
- Alias middleware didaftarkan pada `bootstrap/app.php`.
- Dashboard menampilkan contoh persediaan dari database SQLite.

## Menjalankan aplikasi

1. Jalankan `composer install`.
2. Salin `.env.example` menjadi `.env`.
3. Jalankan `php artisan key:generate`.
4. Jalankan `php artisan migrate:fresh --seed` untuk menyiapkan database dan akun contoh.
5. Jalankan `php artisan serve`, lalu buka URL yang ditampilkan Artisan.

## Akun demo

- Email: `admin@tokokita.test`
- Kata sandi: `Toko123!`

## Menguji

Jalankan `php artisan test`.
