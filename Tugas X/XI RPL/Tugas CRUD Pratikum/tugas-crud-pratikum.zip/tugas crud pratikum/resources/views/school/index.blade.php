@extends('master')

@section('title', 'Data '.$title)

@section('content')
    <p class="eyebrow">Sekolah / {{ $title }}</p>
    <h1>Data {{ $title }}</h1>
    <p class="intro">Kelola data {{ strtolower($title) }} sekolah.</p>

    @if (session('success'))
        <div class="alert success" role="status">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="alert error" role="alert">{{ session('error') }}</div>
    @endif

    <div class="toolbar">
        <p>{{ $records->count() }} data {{ strtolower($title) }}</p>
        <a class="button" href="{{ route($resourceName.'.create') }}">+ Tambah {{ $title }}</a>
    </div>

    <section class="panel" aria-labelledby="data-heading">
        <div class="panel-heading">
            <h2 id="data-heading">Daftar {{ $title }}</h2>
            <p>Data tersimpan dan terhubung sesuai struktur sekolah.</p>
        </div>
        @if ($records->isEmpty())
            <div class="empty-state">Belum ada data. Pilih “Tambah {{ $title }}” untuk memulai.</div>
        @else
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            @foreach ($columns as $column)
                                <th>{{ $column['label'] }}</th>
                            @endforeach
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($records as $record)
                            <tr>
                                @foreach ($columns as $column)
                                    <td>{{ data_get($record, $column['key']) ?: '—' }}</td>
                                @endforeach
                                <td>
                                    <div class="actions">
                                        <a class="button secondary" href="{{ route($resourceName.'.edit', $record) }}">Ubah</a>
                                        <form class="inline-form" action="{{ route($resourceName.'.destroy', $record) }}" method="POST" onsubmit="return confirm('Hapus data ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button class="button danger" type="submit">Hapus</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </section>
@endsection
