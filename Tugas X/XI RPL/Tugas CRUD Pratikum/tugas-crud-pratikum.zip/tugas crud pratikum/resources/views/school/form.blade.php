@extends('master')

@section('title', ($record->exists ? 'Ubah ' : 'Tambah ').$title)

@section('content')
    <p class="eyebrow">Sekolah / {{ $title }}</p>
    <h1>{{ $record->exists ? 'Ubah ' : 'Tambah ' }}{{ $title }}</h1>
    <p class="intro">Isi data {{ strtolower($title) }} pada formulir berikut.</p>

    @if ($errors->any())
        <div class="alert error" role="alert">Periksa kembali data yang dimasukkan.</div>
    @endif

    <section class="panel form-panel">
        <form action="{{ $record->exists ? route($resourceName.'.update', $record) : route($resourceName.'.store') }}" method="POST">
            @csrf
            @if ($record->exists)
                @method('PUT')
            @endif

            <div class="form-grid">
                @foreach ($fields as $field)
                    @php
                        $value = old($field['name'], data_get($record, $field['name']));
                        $required = $field['required'] ?? true;
                    @endphp
                    <div class="field {{ ($field['type'] ?? 'text') === 'textarea' ? 'full' : '' }}">
                        <label for="{{ $field['name'] }}">{{ $field['label'] }}</label>
                        @if (($field['type'] ?? 'text') === 'select')
                            <select id="{{ $field['name'] }}" name="{{ $field['name'] }}" @required($required)>
                                @if ($required)
                                    <option value="" @selected($value === null || $value === '')>Pilih {{ strtolower($field['label']) }}</option>
                                @endif
                                @foreach ($field['options'] as $option)
                                    <option value="{{ $option['value'] }}" @selected((string) $value === (string) $option['value'])>{{ $option['label'] }}</option>
                                @endforeach
                            </select>
                        @elseif (($field['type'] ?? 'text') === 'textarea')
                            <textarea id="{{ $field['name'] }}" name="{{ $field['name'] }}" @required($required)>{{ $value }}</textarea>
                        @else
                            <input id="{{ $field['name'] }}" name="{{ $field['name'] }}" type="{{ $field['type'] ?? 'text' }}" value="{{ $value }}" @required($required)>
                        @endif
                        @error($field['name']) <span class="error-text">{{ $message }}</span> @enderror
                    </div>
                @endforeach
            </div>

            <div class="form-actions">
                <button class="button" type="submit">{{ $record->exists ? 'Simpan Perubahan' : 'Simpan Data' }}</button>
                <a class="button secondary" href="{{ route($resourceName.'.index') }}">Batal</a>
            </div>
        </form>
    </section>
@endsection
