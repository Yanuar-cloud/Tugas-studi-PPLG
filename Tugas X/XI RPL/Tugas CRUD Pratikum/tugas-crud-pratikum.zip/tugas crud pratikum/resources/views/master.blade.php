<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') | Tugas CRUD Praktikum</title>
    <style>
        :root {
            color-scheme: light;
            font-family: "Segoe UI", Arial, sans-serif;
            color: #172033;
            background: #f3f6fb;
        }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; }
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 18px max(20px, calc((100% - 1120px) / 2));
            color: #fff;
            background: #172554;
        }
        .brand { font-size: 18px; font-weight: 700; }
        .brand small { display: block; margin-top: 4px; color: #bfdbfe; font-size: 12px; font-weight: 400; }
        nav { display: flex; flex-wrap: wrap; gap: 6px; }
        .nav-link {
            padding: 9px 13px;
            border-radius: 8px;
            color: #dbeafe;
            font-size: 14px;
            text-decoration: none;
        }
        .nav-link:hover, .nav-link.active { color: #172554; background: #fff; }
        main { width: min(1120px, calc(100% - 40px)); margin: 38px auto; }
        h1 { margin: 0; font-size: clamp(27px, 4vw, 35px); }
        .eyebrow { margin: 0 0 8px; color: #2563eb; font-size: 12px; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; }
        .intro { margin: 9px 0 25px; color: #64748b; }
        .panel { overflow: hidden; border: 1px solid #e2e8f0; border-radius: 14px; background: #fff; box-shadow: 0 10px 28px rgb(15 23 42 / 5%); }
        .panel-heading { padding: 19px 22px; border-bottom: 1px solid #e2e8f0; }
        .panel-heading h2 { margin: 0; font-size: 17px; }
        .panel-heading p { margin: 6px 0 0; color: #64748b; font-size: 13px; }
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th, td { padding: 14px 20px; border-bottom: 1px solid #edf1f6; white-space: nowrap; }
        th { color: #64748b; font-size: 12px; font-weight: 700; letter-spacing: .45px; text-transform: uppercase; }
        td { font-size: 14px; }
        tbody tr:last-child td { border-bottom: 0; }
        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 9px 13px;
            border: 0;
            border-radius: 8px;
            color: #fff;
            background: #2563eb;
            font: inherit;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
        }
        .button:hover { background: #1d4ed8; }
        .button.secondary { color: #334155; background: #e2e8f0; }
        .button.secondary:hover { background: #cbd5e1; }
        .button.danger { background: #dc2626; }
        .button.danger:hover { background: #b91c1c; }
        .toolbar { display: flex; align-items: center; justify-content: space-between; gap: 14px; margin-bottom: 18px; }
        .toolbar p { margin: 0; color: #64748b; font-size: 14px; }
        .actions { display: flex; align-items: center; gap: 7px; }
        .inline-form { display: inline; }
        .form-panel { max-width: 760px; padding: 24px; }
        .form-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; }
        .field { display: grid; gap: 7px; }
        .field.full { grid-column: 1 / -1; }
        .field label { color: #334155; font-size: 14px; font-weight: 600; }
        .field input, .field select, .field textarea {
            width: 100%;
            min-height: 42px;
            padding: 9px 11px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            color: #172033;
            background: #fff;
            font: inherit;
            font-size: 14px;
        }
        .field textarea { min-height: 90px; resize: vertical; }
        .field input:focus, .field select:focus, .field textarea:focus { border-color: #2563eb; outline: 3px solid #dbeafe; }
        .form-actions { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 22px; }
        .alert { margin-bottom: 18px; padding: 13px 15px; border-radius: 9px; font-size: 14px; }
        .alert.success { color: #166534; background: #dcfce7; }
        .alert.error { color: #991b1b; background: #fee2e2; }
        .error-text { color: #b91c1c; font-size: 13px; }
        .empty-state { padding: 30px 20px; color: #64748b; text-align: center; }
        footer { padding: 20px; color: #94a3b8; font-size: 12px; text-align: center; }
        @media (max-width: 760px) {
            header { align-items: flex-start; flex-direction: column; padding: 18px 20px; }
            nav { width: 100%; }
            .nav-link { padding: 8px 10px; }
            main { margin-top: 28px; }
            th, td { padding: 12px 14px; }
        }
        @media (max-width: 560px) {
            .form-grid { grid-template-columns: 1fr; }
            .field.full { grid-column: auto; }
            .toolbar { align-items: flex-start; flex-direction: column; }
        }
    </style>
</head>
<body>
    <header>
        <div class="brand">
            Tugas CRUD Praktikum
            <small>Aplikasi pengelolaan data sekolah</small>
        </div>
        <nav aria-label="Navigasi data sekolah">
            <a class="nav-link {{ request()->routeIs('students.*') ? 'active' : '' }}" href="{{ route('students.index') }}">Siswa</a>
            <a class="nav-link {{ request()->routeIs('classes.*') ? 'active' : '' }}" href="{{ route('classes.index') }}">Kelas</a>
            <a class="nav-link {{ request()->routeIs('majors.*') ? 'active' : '' }}" href="{{ route('majors.index') }}">Jurusan</a>
            <a class="nav-link {{ request()->routeIs('teachers.*') ? 'active' : '' }}" href="{{ route('teachers.index') }}">Guru</a>
            <a class="nav-link {{ request()->routeIs('subjects.*') ? 'active' : '' }}" href="{{ route('subjects.index') }}">Mata Pelajaran</a>
        </nav>
    </header>
    <main>
        @yield('content')
    </main>
    <footer>© 2026 Tugas CRUD Praktikum · Tema Sekolah</footer>
</body>
</html>
