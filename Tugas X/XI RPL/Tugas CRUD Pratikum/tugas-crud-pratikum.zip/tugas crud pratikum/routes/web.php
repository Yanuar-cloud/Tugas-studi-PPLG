<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MajorController;
use App\Http\Controllers\SchoolClassController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\TeacherController;

Route::get('/', [StudentController::class, 'index'])->name('home');

Route::resource('siswa', StudentController::class)
    ->except('show')
    ->parameters(['siswa' => 'record'])
    ->names('students');
Route::resource('kelas', SchoolClassController::class)
    ->except('show')
    ->parameters(['kelas' => 'record'])
    ->names('classes');
Route::resource('jurusan', MajorController::class)
    ->except('show')
    ->parameters(['jurusan' => 'record'])
    ->names('majors');
Route::resource('guru', TeacherController::class)
    ->except('show')
    ->parameters(['guru' => 'record'])
    ->names('teachers');
Route::resource('mapel', SubjectController::class)
    ->except('show')
    ->parameters(['mapel' => 'record'])
    ->names('subjects');
