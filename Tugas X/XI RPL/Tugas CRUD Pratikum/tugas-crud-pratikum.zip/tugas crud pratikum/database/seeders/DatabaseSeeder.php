<?php

namespace Database\Seeders;

use App\Models\Major;
use App\Models\SchoolClass;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $rpl = Major::updateOrCreate(
            ['code' => 'RPL'],
            ['name' => 'Rekayasa Perangkat Lunak', 'description' => 'Pengembangan aplikasi web dan perangkat lunak.'],
        );
        $tkj = Major::updateOrCreate(
            ['code' => 'TKJ'],
            ['name' => 'Teknik Komputer dan Jaringan', 'description' => 'Komputer, jaringan, dan infrastruktur digital.'],
        );

        $classRpl = SchoolClass::updateOrCreate(
            ['name' => 'XI RPL 1'],
            ['grade' => 'XI', 'major_id' => $rpl->id],
        );
        SchoolClass::updateOrCreate(
            ['name' => 'X TKJ 1'],
            ['grade' => 'X', 'major_id' => $tkj->id],
        );

        $teacher = Teacher::updateOrCreate(
            ['nip' => '198701012015011001'],
            ['name' => 'Dedi Saputra', 'email' => 'dedi@sekolah.test', 'phone' => '081234567890'],
        );
        Subject::updateOrCreate(
            ['code' => 'RPL101'],
            ['name' => 'Pemrograman Web', 'major_id' => $rpl->id, 'teacher_id' => $teacher->id],
        );

        Student::updateOrCreate(
            ['nis' => '1126001'],
            ['name' => 'Alya Putri', 'gender' => 'P', 'school_class_id' => $classRpl->id],
        );
        Student::updateOrCreate(
            ['nis' => '1126002'],
            ['name' => 'Bima Pratama', 'gender' => 'L', 'school_class_id' => $classRpl->id],
        );
    }
}
