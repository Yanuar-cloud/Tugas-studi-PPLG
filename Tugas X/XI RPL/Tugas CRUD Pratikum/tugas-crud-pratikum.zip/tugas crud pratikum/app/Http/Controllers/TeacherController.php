<?php

namespace App\Http\Controllers;

use App\Models\Teacher;
use Illuminate\Database\Eloquent\Model;

class TeacherController extends SchoolResourceController
{
    protected function modelClass(): string
    {
        return Teacher::class;
    }

    protected function resourceName(): string
    {
        return 'teachers';
    }

    protected function title(): string
    {
        return 'Guru';
    }

    protected function columns(): array
    {
        return [
            ['label' => 'NIP', 'key' => 'nip'],
            ['label' => 'Nama', 'key' => 'name'],
            ['label' => 'Email', 'key' => 'email'],
            ['label' => 'Telepon', 'key' => 'phone'],
        ];
    }

    protected function fields(): array
    {
        return [
            ['name' => 'nip', 'label' => 'NIP', 'type' => 'text'],
            ['name' => 'name', 'label' => 'Nama Guru', 'type' => 'text'],
            ['name' => 'email', 'label' => 'Email', 'type' => 'email'],
            ['name' => 'phone', 'label' => 'Nomor Telepon', 'type' => 'text', 'required' => false],
        ];
    }

    protected function rules(?Model $record = null): array
    {
        return [
            'nip' => ['required', 'string', 'max:30', $this->unique('teachers', 'nip', $record)],
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:255', $this->unique('teachers', 'email', $record)],
            'phone' => ['nullable', 'string', 'max:30'],
        ];
    }

    protected function deleteBlockMessage(Model $record): ?string
    {
        if ($record->subjects()->exists()) {
            return 'Guru masih ditugaskan pada mata pelajaran. Ubah penugasan terlebih dahulu.';
        }

        return null;
    }
}
