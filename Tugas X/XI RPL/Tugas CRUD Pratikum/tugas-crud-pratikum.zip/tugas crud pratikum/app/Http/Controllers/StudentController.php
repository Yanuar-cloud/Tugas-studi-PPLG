<?php

namespace App\Http\Controllers;

use App\Models\SchoolClass;
use App\Models\Student;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;

class StudentController extends SchoolResourceController
{
    protected function modelClass(): string
    {
        return Student::class;
    }

    protected function resourceName(): string
    {
        return 'students';
    }

    protected function title(): string
    {
        return 'Siswa';
    }

    protected function columns(): array
    {
        return [
            ['label' => 'NIS', 'key' => 'nis'],
            ['label' => 'Nama', 'key' => 'name'],
            ['label' => 'Jenis Kelamin', 'key' => 'gender_label'],
            ['label' => 'Kelas', 'key' => 'schoolClass.name'],
            ['label' => 'Jurusan', 'key' => 'schoolClass.major.name'],
        ];
    }

    protected function fields(): array
    {
        return [
            ['name' => 'nis', 'label' => 'NIS', 'type' => 'text'],
            ['name' => 'name', 'label' => 'Nama Siswa', 'type' => 'text'],
            [
                'name' => 'gender',
                'label' => 'Jenis Kelamin',
                'type' => 'select',
                'options' => [
                    ['value' => 'L', 'label' => 'Laki-laki'],
                    ['value' => 'P', 'label' => 'Perempuan'],
                ],
            ],
            [
                'name' => 'school_class_id',
                'label' => 'Kelas',
                'type' => 'select',
                'options' => SchoolClass::query()
                    ->with('major')
                    ->orderBy('name')
                    ->get()
                    ->map(fn (SchoolClass $class): array => [
                        'value' => $class->id,
                        'label' => $class->name.' — '.$class->major->name,
                    ])
                    ->all(),
            ],
        ];
    }

    protected function rules(?Model $record = null): array
    {
        return [
            'nis' => ['required', 'string', 'max:20', $this->unique('students', 'nis', $record)],
            'name' => ['required', 'string', 'max:100'],
            'gender' => ['required', Rule::in(['L', 'P'])],
            'school_class_id' => ['required', 'integer', Rule::exists('school_classes', 'id')],
        ];
    }

    protected function eagerLoads(): array
    {
        return ['schoolClass.major'];
    }

    protected function deleteBlockMessage(Model $record): ?string
    {
        return null;
    }
}
