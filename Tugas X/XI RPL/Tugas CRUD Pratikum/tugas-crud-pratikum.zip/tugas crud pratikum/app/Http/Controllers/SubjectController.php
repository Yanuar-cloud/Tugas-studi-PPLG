<?php

namespace App\Http\Controllers;

use App\Models\Major;
use App\Models\Subject;
use App\Models\Teacher;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;

class SubjectController extends SchoolResourceController
{
    protected function modelClass(): string
    {
        return Subject::class;
    }

    protected function resourceName(): string
    {
        return 'subjects';
    }

    protected function title(): string
    {
        return 'Mata Pelajaran';
    }

    protected function columns(): array
    {
        return [
            ['label' => 'Kode', 'key' => 'code'],
            ['label' => 'Mata Pelajaran', 'key' => 'name'],
            ['label' => 'Jurusan', 'key' => 'major.name'],
            ['label' => 'Guru', 'key' => 'teacher.name'],
        ];
    }

    protected function fields(): array
    {
        return [
            ['name' => 'code', 'label' => 'Kode Mata Pelajaran', 'type' => 'text'],
            ['name' => 'name', 'label' => 'Nama Mata Pelajaran', 'type' => 'text'],
            [
                'name' => 'major_id',
                'label' => 'Jurusan',
                'type' => 'select',
                'options' => Major::query()->orderBy('name')->get()
                    ->map(fn (Major $major): array => ['value' => $major->id, 'label' => $major->name])
                    ->all(),
            ],
            [
                'name' => 'teacher_id',
                'label' => 'Guru Pengampu',
                'type' => 'select',
                'required' => false,
                'options' => array_merge(
                    [['value' => '', 'label' => 'Belum ditentukan']],
                    Teacher::query()->orderBy('name')->get()
                        ->map(fn (Teacher $teacher): array => ['value' => $teacher->id, 'label' => $teacher->name])
                        ->all(),
                ),
            ],
        ];
    }

    protected function rules(?Model $record = null): array
    {
        return [
            'code' => ['required', 'string', 'max:15', $this->unique('subjects', 'code', $record)],
            'name' => ['required', 'string', 'max:100'],
            'major_id' => ['required', 'integer', Rule::exists('majors', 'id')],
            'teacher_id' => ['nullable', 'integer', Rule::exists('teachers', 'id')],
        ];
    }

    protected function eagerLoads(): array
    {
        return ['major', 'teacher'];
    }
}
