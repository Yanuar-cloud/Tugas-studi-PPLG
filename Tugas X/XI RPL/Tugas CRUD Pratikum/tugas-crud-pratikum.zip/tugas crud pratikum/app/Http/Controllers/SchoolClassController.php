<?php

namespace App\Http\Controllers;

use App\Models\Major;
use App\Models\SchoolClass;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;

class SchoolClassController extends SchoolResourceController
{
    protected function modelClass(): string
    {
        return SchoolClass::class;
    }

    protected function resourceName(): string
    {
        return 'classes';
    }

    protected function title(): string
    {
        return 'Kelas';
    }

    protected function columns(): array
    {
        return [
            ['label' => 'Nama Kelas', 'key' => 'name'],
            ['label' => 'Tingkat', 'key' => 'grade'],
            ['label' => 'Jurusan', 'key' => 'major.name'],
        ];
    }

    protected function fields(): array
    {
        return [
            ['name' => 'name', 'label' => 'Nama Kelas', 'type' => 'text'],
            [
                'name' => 'grade',
                'label' => 'Tingkat',
                'type' => 'select',
                'options' => [
                    ['value' => 'X', 'label' => 'X'],
                    ['value' => 'XI', 'label' => 'XI'],
                    ['value' => 'XII', 'label' => 'XII'],
                ],
            ],
            [
                'name' => 'major_id',
                'label' => 'Jurusan',
                'type' => 'select',
                'options' => Major::query()->orderBy('name')->get()
                    ->map(fn (Major $major): array => ['value' => $major->id, 'label' => $major->name])
                    ->all(),
            ],
        ];
    }

    protected function rules(?Model $record = null): array
    {
        return [
            'name' => ['required', 'string', 'max:50', $this->unique('school_classes', 'name', $record)],
            'grade' => ['required', Rule::in(['X', 'XI', 'XII'])],
            'major_id' => ['required', 'integer', Rule::exists('majors', 'id')],
        ];
    }

    protected function eagerLoads(): array
    {
        return ['major'];
    }

    protected function deleteBlockMessage(Model $record): ?string
    {
        if ($record->students()->exists()) {
            return 'Kelas masih memiliki siswa. Pindahkan siswa terlebih dahulu.';
        }

        return null;
    }
}
