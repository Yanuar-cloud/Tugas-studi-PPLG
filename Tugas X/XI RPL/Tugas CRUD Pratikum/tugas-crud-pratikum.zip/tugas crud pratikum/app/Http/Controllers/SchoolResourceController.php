<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

abstract class SchoolResourceController extends Controller
{
    /**
     * @return class-string<Model>
     */
    abstract protected function modelClass(): string;

    abstract protected function resourceName(): string;

    abstract protected function title(): string;

    abstract protected function columns(): array;

    abstract protected function fields(): array;

    abstract protected function rules(?Model $record = null): array;

    protected function eagerLoads(): array
    {
        return [];
    }

    protected function deleteBlockMessage(Model $record): ?string
    {
        return null;
    }

    protected function unique(string $table, string $column, ?Model $record = null): \Illuminate\Validation\Rules\Unique
    {
        $rule = Rule::unique($table, $column);

        if ($record !== null) {
            $rule->ignore($record->getKey());
        }

        return $rule;
    }

    public function index(): View
    {
        $model = $this->modelClass();
        $records = $model::query()
            ->with($this->eagerLoads())
            ->orderByDesc('id')
            ->get();

        return view('school.index', [
            'title' => $this->title(),
            'resourceName' => $this->resourceName(),
            'columns' => $this->columns(),
            'records' => $records,
        ]);
    }

    public function create(): View
    {
        $model = $this->modelClass();

        return view('school.form', [
            'title' => $this->title(),
            'resourceName' => $this->resourceName(),
            'fields' => $this->fields(),
            'record' => new $model(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $model = $this->modelClass();
        $model::create($request->validate($this->rules(), $this->messages()));

        return redirect()->route($this->resourceName().'.index')
            ->with('success', $this->title().' berhasil ditambahkan.');
    }

    public function edit(int $record): View
    {
        $model = $this->modelClass();

        return view('school.form', [
            'title' => $this->title(),
            'resourceName' => $this->resourceName(),
            'fields' => $this->fields(),
            'record' => $model::findOrFail($record),
        ]);
    }

    public function update(Request $request, int $record): RedirectResponse
    {
        $model = $this->modelClass();
        $item = $model::findOrFail($record);
        $item->update($request->validate($this->rules($item), $this->messages()));

        return redirect()->route($this->resourceName().'.index')
            ->with('success', $this->title().' berhasil diperbarui.');
    }

    public function destroy(int $record): RedirectResponse
    {
        $model = $this->modelClass();
        $item = $model::findOrFail($record);
        $message = $this->deleteBlockMessage($item);

        if ($message !== null) {
            return back()->with('error', $message);
        }

        $item->delete();

        return redirect()->route($this->resourceName().'.index')
            ->with('success', $this->title().' berhasil dihapus.');
    }

    private function messages(): array
    {
        return [
            'required' => 'Kolom :attribute wajib diisi.',
            'unique' => ':attribute sudah digunakan.',
            'exists' => 'Pilihan :attribute tidak valid.',
            'email' => 'Masukkan alamat email yang valid.',
            'in' => 'Pilihan :attribute tidak valid.',
        ];
    }
}
