<?php

namespace App\Http\Controllers;

use App\Models\Major;
use Illuminate\Database\Eloquent\Model;

class MajorController extends SchoolResourceController
{
    protected function modelClass(): string
    {
        return Major::class;
    }

    protected function resourceName(): string
    {
        return 'majors';
    }

    protected function title(): string
    {
        return 'Jurusan';
    }

    protected function columns(): array
    {
        return [
            ['label' => 'Kode', 'key' => 'code'],
            ['label' => 'Nama Jurusan', 'key' => 'name'],
            ['label' => 'Deskripsi', 'key' => 'description'],
        ];
    }

    protected function fields(): array
    {
        return [
            ['name' => 'code', 'label' => 'Kode Jurusan', 'type' => 'text'],
            ['name' => 'name', 'label' => 'Nama Jurusan', 'type' => 'text'],
            ['name' => 'description', 'label' => 'Deskripsi', 'type' => 'textarea', 'required' => false],
        ];
    }

    protected function rules(?Model $record = null): array
    {
        return [
            'code' => ['required', 'string', 'max:10', $this->unique('majors', 'code', $record)],
            'name' => ['required', 'string', 'max:100', $this->unique('majors', 'name', $record)],
            'description' => ['nullable', 'string', 'max:1000'],
        ];
    }

    protected function deleteBlockMessage(Model $record): ?string
    {
        if ($record->classes()->exists() || $record->subjects()->exists()) {
            return 'Jurusan masih dipakai oleh kelas atau mata pelajaran. Hapus data terkait terlebih dahulu.';
        }

        return null;
    }
}
