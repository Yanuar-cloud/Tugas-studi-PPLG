<?php

namespace Tests\Feature;

use App\Models\Major;
use App\Models\SchoolClass;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Teacher;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SchoolCrudTest extends TestCase
{
    use RefreshDatabase;

    public function test_all_five_school_data_sections_have_read_and_create_pages(): void
    {
        foreach (['students', 'classes', 'majors', 'teachers', 'subjects'] as $resource) {
            $this->get(route($resource.'.index'))->assertOk();
            $this->get(route($resource.'.create'))->assertOk();
        }
    }

    public function test_student_crud_uses_related_class_and_major_data(): void
    {
        $major = Major::create(['code' => 'RPL', 'name' => 'Rekayasa Perangkat Lunak']);
        $class = SchoolClass::create(['name' => 'XI RPL 1', 'grade' => 'XI', 'major_id' => $major->id]);

        $this->post(route('students.store'), [
            'nis' => '1126003',
            'name' => 'Citra Lestari',
            'gender' => 'P',
            'school_class_id' => $class->id,
        ])->assertRedirect(route('students.index'));

        $student = Student::where('nis', '1126003')->firstOrFail();
        $this->assertSame('Rekayasa Perangkat Lunak', $student->schoolClass->major->name);

        $this->put(route('students.update', $student), [
            'nis' => '1126003',
            'name' => 'Citra Wijaya',
            'gender' => 'P',
            'school_class_id' => $class->id,
        ])->assertRedirect(route('students.index'));

        $this->assertDatabaseHas('students', ['id' => $student->id, 'name' => 'Citra Wijaya']);

        $this->delete(route('students.destroy', $student))
            ->assertRedirect(route('students.index'));
        $this->assertDatabaseMissing('students', ['id' => $student->id]);
    }

    public function test_related_records_cannot_be_deleted_while_in_use(): void
    {
        $major = Major::create(['code' => 'RPL', 'name' => 'Rekayasa Perangkat Lunak']);
        $class = SchoolClass::create(['name' => 'XI RPL 1', 'grade' => 'XI', 'major_id' => $major->id]);
        Student::create([
            'nis' => '1126004',
            'name' => 'Dina',
            'gender' => 'P',
            'school_class_id' => $class->id,
        ]);

        $this->from(route('classes.index'))
            ->delete(route('classes.destroy', $class))
            ->assertSessionHas('error');

        $this->assertDatabaseHas('school_classes', ['id' => $class->id]);
    }

    public function test_subject_links_a_major_and_teacher(): void
    {
        $major = Major::create(['code' => 'RPL', 'name' => 'Rekayasa Perangkat Lunak']);
        $teacher = Teacher::create([
            'nip' => '123456789',
            'name' => 'Dedi Saputra',
            'email' => 'dedi@example.test',
        ]);

        $this->post(route('subjects.store'), [
            'code' => 'RPL101',
            'name' => 'Pemrograman Web',
            'major_id' => $major->id,
            'teacher_id' => $teacher->id,
        ])->assertRedirect(route('subjects.index'));

        $subject = Subject::where('code', 'RPL101')->firstOrFail();
        $this->assertSame($major->id, $subject->major->id);
        $this->assertSame($teacher->id, $subject->teacher->id);
    }
}
