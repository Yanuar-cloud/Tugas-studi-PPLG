# Tugas CRUD Praktikum

Aplikasi CRUD sederhana dengan tema **Sekolah**. Data utama dikelola melalui menu Siswa, Kelas, Jurusan, Guru, dan Mata Pelajaran.

## Relasi tabel

- `majors` memiliki banyak `school_classes` dan `subjects`.
- `school_classes` memiliki banyak `students`.
- `teachers` mengampu banyak `subjects`.
- `subjects` terhubung ke `majors` dan `teachers`.
- `students` terhubung ke `school_classes`.

## Menjalankan aplikasi

1. Jalankan `composer install`.
2. Salin `.env.example` menjadi `.env`.
3. Jalankan `php artisan key:generate`.
4. Jalankan `php artisan migrate:fresh --seed` untuk membuat tabel dan data contoh.
5. Jalankan `php artisan serve` lalu buka URL yang ditampilkan oleh Artisan.

> Perintah `migrate:fresh` menghapus tabel dan data lokal sebelum membuat ulang database.

## Menguji

Jalankan `php artisan test`.
