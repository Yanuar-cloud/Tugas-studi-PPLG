<?php

use Illuminate\Support\Facades\Route;
use App\Models\Flower;
use App\Models\GardenBed;

Route::get('/', function () {
    return view('garden', [
        'flowers' => Flower::query()
            ->with(['careGuide', 'gardenBed', 'pollinators'])
            ->orderBy('name')
            ->get(),
        'beds' => GardenBed::query()
            ->with('flowers')
            ->orderBy('name')
            ->get(),
    ]);
});
