<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('flower_pollinator', function (Blueprint $table) {
            $table->foreignId('flower_id')->constrained()->cascadeOnDelete();
            $table->foreignId('pollinator_id')->constrained()->cascadeOnDelete();
            $table->string('relationship_note', 160)->nullable();
            $table->timestamps();
            $table->primary(['flower_id', 'pollinator_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('flower_pollinator');
    }
};
