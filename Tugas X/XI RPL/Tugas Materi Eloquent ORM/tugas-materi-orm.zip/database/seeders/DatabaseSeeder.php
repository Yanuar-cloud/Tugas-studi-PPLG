<?php

namespace Database\Seeders;

use App\Models\CareGuide;
use App\Models\Flower;
use App\Models\GardenBed;
use App\Models\Pollinator;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $sunnyBed = GardenBed::updateOrCreate(
            ['name' => 'Petak Mentari'],
            [
                'location' => 'Sisi timur taman',
                'soil_type' => 'Humus lembap',
                'description' => 'Petak hangat dengan cahaya pagi yang melimpah.',
            ],
        );
        $shadeBed = GardenBed::updateOrCreate(
            ['name' => 'Sudut Embun'],
            [
                'location' => 'Dekat pergola',
                'soil_type' => 'Kompos gembur',
                'description' => 'Area teduh untuk bunga yang menyukai udara sejuk.',
            ],
        );

        $dahlia = Flower::updateOrCreate(
            ['latin_name' => 'Dahlia pinnata'],
            ['name' => 'Dahlia Senja', 'color' => 'Merah muda', 'garden_bed_id' => $sunnyBed->id],
        );
        $melati = Flower::updateOrCreate(
            ['latin_name' => 'Jasminum sambac'],
            ['name' => 'Melati Putih', 'color' => 'Putih gading', 'garden_bed_id' => $sunnyBed->id],
        );
        $lavender = Flower::updateOrCreate(
            ['latin_name' => 'Lavandula angustifolia'],
            ['name' => 'Lavender Ungu', 'color' => 'Ungu lembut', 'garden_bed_id' => $shadeBed->id],
        );

        CareGuide::updateOrCreate(
            ['flower_id' => $dahlia->id],
            [
                'sunlight_hours' => 6,
                'watering' => 'Siram saat permukaan tanah mulai kering.',
                'care_tip' => 'Pangkas bunga layu agar tunas baru tumbuh.',
            ],
        );
        CareGuide::updateOrCreate(
            ['flower_id' => $melati->id],
            [
                'sunlight_hours' => 5,
                'watering' => 'Siram secukupnya setiap pagi.',
                'care_tip' => 'Letakkan di tempat terang dengan sirkulasi udara baik.',
            ],
        );
        CareGuide::updateOrCreate(
            ['flower_id' => $lavender->id],
            [
                'sunlight_hours' => 7,
                'watering' => 'Biarkan media tanam mengering di antara penyiraman.',
                'care_tip' => 'Pastikan pot memiliki drainase yang baik.',
            ],
        );

        $bee = Pollinator::updateOrCreate(
            ['species' => 'Apis mellifera'],
            ['name' => 'Lebah Madu', 'kind' => 'Lebah'],
        );
        $butterfly = Pollinator::updateOrCreate(
            ['species' => 'Danaus plexippus'],
            ['name' => 'Kupu-kupu Raja', 'kind' => 'Kupu-kupu'],
        );
        $beetle = Pollinator::updateOrCreate(
            ['species' => 'Cetonia aurata'],
            ['name' => 'Kumbang Bunga', 'kind' => 'Kumbang'],
        );

        $dahlia->pollinators()->sync([
            $bee->id => ['relationship_note' => 'Mencari nektar saat pagi.'],
            $butterfly->id => ['relationship_note' => 'Sering hinggap di kelopak.'],
        ]);
        $melati->pollinators()->sync([
            $bee->id => ['relationship_note' => 'Mengunjungi bunga yang mekar.'],
            $beetle->id => ['relationship_note' => 'Membantu penyerbukan silang.'],
        ]);
        $lavender->pollinators()->sync([
            $bee->id => ['relationship_note' => 'Menyukai bunga lavender.'],
            $butterfly->id => ['relationship_note' => 'Datang pada siang cerah.'],
        ]);
    }
}
