<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Flower extends Model
{
    protected $fillable = ['name', 'latin_name', 'color', 'garden_bed_id'];

    public function careGuide(): HasOne
    {
        return $this->hasOne(CareGuide::class);
    }

    public function gardenBed(): BelongsTo
    {
        return $this->belongsTo(GardenBed::class);
    }

    public function pollinators(): BelongsToMany
    {
        return $this->belongsToMany(Pollinator::class)
            ->withPivot('relationship_note')
            ->withTimestamps();
    }
}
