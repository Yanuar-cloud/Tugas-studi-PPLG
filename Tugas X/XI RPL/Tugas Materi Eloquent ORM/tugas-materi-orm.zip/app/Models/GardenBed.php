<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class GardenBed extends Model
{
    protected $fillable = ['name', 'location', 'soil_type', 'description'];

    public function flowers(): HasMany
    {
        return $this->hasMany(Flower::class);
    }
}
