<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Pollinator extends Model
{
    protected $fillable = ['name', 'species', 'kind'];

    public function flowers(): BelongsToMany
    {
        return $this->belongsToMany(Flower::class)
            ->withPivot('relationship_note')
            ->withTimestamps();
    }
}
