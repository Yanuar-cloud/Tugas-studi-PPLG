<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CareGuide extends Model
{
    protected $fillable = ['flower_id', 'sunlight_hours', 'watering', 'care_tip'];

    public function flower(): BelongsTo
    {
        return $this->belongsTo(Flower::class);
    }
}
