<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Taman Bunga ORM · Catatan Kebun</title>
    <style>
        :root {
            font-family: "Trebuchet MS", Arial, sans-serif;
            color: #233c32;
            background: #f7f5eb;
            font-synthesis: none;
        }
        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body { margin: 0; min-width: 320px; }
        a { color: inherit; }
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: min(1240px, calc(100% - 64px));
            margin: auto;
            padding: 26px 0;
        }
        .logo { display: flex; align-items: center; gap: 11px; font-size: 15px; font-weight: 800; letter-spacing: 1.4px; }
        .logo-mark { display: grid; width: 35px; height: 35px; place-items: center; border-radius: 50%; color: #fffaf0; background: #d27762; font-size: 20px; }
        .logo small { display: block; margin-top: 3px; color: #7a8a74; font-size: 9px; font-weight: 600; letter-spacing: 1.8px; }
        .edition { padding: 8px 13px; border: 1px solid #d6dac8; border-radius: 99px; color: #647765; font-size: 10px; font-weight: 700; letter-spacing: 1.4px; }
        .hero {
            position: relative;
            display: grid;
            grid-template-columns: 1.1fr .9fr;
            align-items: center;
            width: min(1240px, calc(100% - 64px));
            min-height: 430px;
            margin: 0 auto 54px;
            padding: 54px 7%;
            overflow: hidden;
            border-radius: 8px 90px 8px 8px;
            background: #e5eadb;
        }
        .hero-copy { position: relative; z-index: 1; max-width: 590px; }
        .kicker { margin: 0 0 17px; color: #b25e4b; font-size: 10px; font-weight: 800; letter-spacing: 2.4px; }
        h1, h2, h3 { font-family: Georgia, "Times New Roman", serif; }
        .hero h1 { margin: 0; color: #244333; font-size: clamp(42px, 6vw, 72px); font-weight: 400; letter-spacing: -2.7px; line-height: .99; }
        .hero-copy > p:not(.kicker) { max-width: 450px; margin: 20px 0 27px; color: #627568; font-size: 15px; line-height: 1.7; }
        .hero-link { display: inline-block; padding: 12px 17px; border-radius: 3px; color: #fffaf0; background: #315742; font-size: 12px; font-weight: 700; letter-spacing: .3px; text-decoration: none; }
        .hero-art { position: relative; min-height: 300px; }
        .sun { position: absolute; top: 20px; right: 12%; width: 215px; height: 215px; border-radius: 50%; background: #eec29f; }
        .flower-art { position: absolute; top: 30px; right: 15%; z-index: 1; color: #bd6459; font-size: 196px; line-height: 1; transform: rotate(-12deg); text-shadow: 23px 20px 0 #e3967d, -18px 30px 0 #d9a15d; }
        .stem { position: absolute; right: 35%; bottom: -7px; width: 8px; height: 155px; border-radius: 99px; background: #5e815f; transform: rotate(12deg); }
        .leaf { position: absolute; right: 23%; bottom: 60px; z-index: 2; width: 72px; height: 34px; border-radius: 100% 0 100% 0; background: #78956e; transform: rotate(-23deg); }
        .leaf.second { right: 44%; bottom: 28px; transform: rotate(29deg) scaleX(-1); }
        .hero-note { position: absolute; right: 0; bottom: 17px; z-index: 2; padding: 12px 15px; border: 1px solid rgb(49 87 66 / 18%); border-radius: 3px; color: #49624f; background: rgb(247 245 235 / 84%); font-family: Georgia, serif; font-size: 12px; font-style: italic; }
        .stats { display: flex; flex-wrap: wrap; gap: 12px; width: min(1240px, calc(100% - 64px)); margin: 0 auto 60px; }
        .stat { min-width: 150px; padding: 14px 18px; border-left: 2px solid #d7866e; }
        .stat strong { display: block; color: #315742; font-family: Georgia, serif; font-size: 25px; font-weight: 400; }
        .stat span { display: block; margin-top: 3px; color: #7d8878; font-size: 10px; font-weight: 700; letter-spacing: 1.2px; text-transform: uppercase; }
        .collection { width: min(1240px, calc(100% - 64px)); margin: 0 auto 64px; }
        .section-head { display: flex; align-items: end; justify-content: space-between; gap: 20px; margin-bottom: 20px; }
        .section-head .kicker { margin-bottom: 8px; }
        .section-head h2 { margin: 0; color: #284736; font-size: clamp(26px, 3vw, 36px); font-weight: 400; }
        .relation-tag { padding: 7px 10px; border: 1px solid #d8d8c8; border-radius: 2px; color: #6b796b; font-family: "Trebuchet MS", Arial, sans-serif; font-size: 9px; font-weight: 800; letter-spacing: 1.1px; white-space: nowrap; }
        .one-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
        .care-card { position: relative; min-height: 225px; padding: 23px; border: 1px solid #eadfd1; border-radius: 3px 30px 3px 3px; background: #fffdf7; }
        .care-card::after { position: absolute; top: 16px; right: 18px; color: #d9ad91; content: "✿"; font-size: 23px; }
        .latin { margin: 0 0 7px; color: #a56d5c; font-family: Georgia, serif; font-size: 12px; font-style: italic; }
        .care-card h3 { margin: 0 0 17px; color: #284736; font-size: 23px; font-weight: 400; }
        .sun-hours { display: inline-flex; align-items: center; gap: 7px; margin-bottom: 12px; padding: 7px 10px; border-radius: 20px; color: #806344; background: #f6ecd7; font-size: 11px; font-weight: 700; }
        .care-card p:last-child { margin: 0; color: #778276; font-size: 12px; line-height: 1.6; }
        .beds { display: grid; grid-template-columns: repeat(2, 1fr); gap: 18px; }
        .bed-card { padding: 22px 24px; border-radius: 3px; color: #eff2e7; background: #315742; }
        .bed-card:nth-child(even) { color: #354d3d; background: #dce5d2; }
        .bed-top { display: flex; align-items: start; justify-content: space-between; gap: 10px; padding-bottom: 16px; border-bottom: 1px solid rgb(255 255 255 / 22%); }
        .bed-card:nth-child(even) .bed-top { border-color: rgb(53 77 61 / 20%); }
        .bed-card h3 { margin: 0; font-size: 25px; font-weight: 400; }
        .bed-top span { font-size: 10px; opacity: .75; }
        .bed-location { margin: 12px 0; font-size: 11px; opacity: .78; }
        .flower-list { display: flex; flex-wrap: wrap; gap: 8px; }
        .flower-chip { padding: 7px 10px; border: 1px solid rgb(255 255 255 / 32%); border-radius: 99px; font-size: 11px; }
        .bed-card:nth-child(even) .flower-chip { border-color: rgb(53 77 61 / 25%); }
        .pollinator-list { border-top: 1px solid #e4dfd1; }
        .pollinator-row { display: grid; grid-template-columns: 1.1fr 1fr 1.2fr; align-items: center; gap: 16px; padding: 16px 10px; border-bottom: 1px solid #e4dfd1; }
        .pollinator-flower { color: #a45e50; font-family: Georgia, serif; font-size: 17px; }
        .pollinator-names { display: flex; flex-wrap: wrap; gap: 6px; }
        .pollinator-pill { padding: 6px 9px; border-radius: 2px 12px 2px 12px; color: #47664e; background: #e5eadb; font-size: 10px; font-weight: 700; }
        .pollinator-note { color: #829080; font-size: 11px; line-height: 1.5; }
        .closing { display: flex; align-items: center; justify-content: space-between; gap: 18px; width: min(1240px, calc(100% - 64px)); margin: 0 auto 30px; padding: 25px 0; border-top: 1px solid #dddccc; color: #889182; font-size: 11px; }
        .closing strong { color: #47664e; font-family: Georgia, serif; font-size: 16px; font-weight: 400; }
        @media (max-width: 800px) {
            .topbar, .hero, .stats, .collection, .closing { width: min(100% - 36px, 620px); }
            .hero { grid-template-columns: 1fr; padding: 42px 32px 0; }
            .hero-art { min-height: 250px; margin-top: 10px; }
            .sun { right: 25%; width: 175px; height: 175px; }
            .flower-art { right: 27%; font-size: 160px; }
            .one-grid { grid-template-columns: 1fr; }
            .care-card { min-height: 0; }
        }
        @media (max-width: 560px) {
            .topbar { padding: 18px 0; }
            .edition { font-size: 8px; }
            .hero { min-height: 0; padding: 34px 24px 0; border-top-right-radius: 55px; }
            .hero h1 { font-size: 48px; }
            .hero-art { min-height: 220px; }
            .sun { right: 18%; width: 155px; height: 155px; }
            .flower-art { right: 21%; font-size: 140px; }
            .stats { gap: 4px; margin-bottom: 42px; }
            .stat { min-width: 0; flex: 1; padding: 10px; }
            .stat strong { font-size: 21px; }
            .stat span { font-size: 8px; letter-spacing: .6px; }
            .section-head { align-items: start; flex-direction: column; }
            .beds { grid-template-columns: 1fr; }
            .pollinator-row { grid-template-columns: 1fr; gap: 8px; }
            .closing { align-items: start; flex-direction: column; }
        }
    </style>
</head>
<body>
    <header class="topbar">
        <div class="logo">
            <span class="logo-mark" aria-hidden="true">✿</span>
            <span>PETAL &amp; ROOT<small>CATATAN TAMAN BUNGA</small></span>
        </div>
        <span class="edition">HERBARIUM · NO. 01</span>
    </header>

    <main>
        <section class="hero">
            <div class="hero-copy">
                <p class="kicker">MENANAM · MERAWAT · BERTUMBUH</p>
                <h1>Ruang kecil untuk banyak bunga.</h1>
                <p>Jelajahi koleksi bunga, petak taman, panduan perawatan, dan para penyerbuk yang datang berkunjung.</p>
                <a class="hero-link" href="#koleksi">Jelajahi kebun <span aria-hidden="true">↘</span></a>
            </div>
            <div class="hero-art" aria-hidden="true">
                <div class="sun"></div>
                <div class="flower-art">✿</div>
                <div class="stem"></div>
                <div class="leaf"></div>
                <div class="leaf second"></div>
                <div class="hero-note">Dibuat dengan rasa ingin tahu 🌱</div>
            </div>
        </section>

        <div class="stats" aria-label="Ringkasan taman">
            <div class="stat"><strong>{{ $flowers->count() }}</strong><span>Jenis bunga</span></div>
            <div class="stat"><strong>{{ $beds->count() }}</strong><span>Petak taman</span></div>
            <div class="stat"><strong>{{ $flowers->pluck('pollinators')->flatten()->unique('id')->count() }}</strong><span>Penyerbuk</span></div>
        </div>

        <section class="collection" id="koleksi">
            <div class="section-head">
                <div>
                    <p class="kicker">01 · PROFIL PERAWATAN</p>
                    <h2>Setiap bunga punya catatan kecil.</h2>
                </div>
                <span class="relation-tag">HAS ONE · ONE TO ONE</span>
            </div>
            <div class="one-grid">
                @foreach ($flowers as $flower)
                    @if ($flower->careGuide)
                        <article class="care-card">
                            <p class="latin">{{ $flower->latin_name }}</p>
                            <h3>{{ $flower->name }}</h3>
                            <span class="sun-hours"><span aria-hidden="true">☼</span> {{ $flower->careGuide->sunlight_hours }} jam matahari</span>
                            <p>{{ $flower->careGuide->watering }} {{ $flower->careGuide->care_tip }}</p>
                        </article>
                    @endif
                @endforeach
            </div>
        </section>

        <section class="collection">
            <div class="section-head">
                <div>
                    <p class="kicker">02 · PETA KEBUN</p>
                    <h2>Satu petak, banyak warna.</h2>
                </div>
                <span class="relation-tag">HAS MANY · ONE TO MANY</span>
            </div>
            <div class="beds">
                @foreach ($beds as $bed)
                    <article class="bed-card">
                        <div class="bed-top">
                            <h3>{{ $bed->name }}</h3>
                            <span>{{ $bed->flowers->count() }} bunga</span>
                        </div>
                        <p class="bed-location">{{ $bed->location }} · {{ $bed->soil_type }}</p>
                        <div class="flower-list">
                            @foreach ($bed->flowers as $flower)
                                <span class="flower-chip">{{ $flower->name }} · {{ $flower->color }}</span>
                            @endforeach
                        </div>
                    </article>
                @endforeach
            </div>
        </section>

        <section class="collection">
            <div class="section-head">
                <div>
                    <p class="kicker">03 · TAMU TAMAN</p>
                    <h2>Bunga dan sahabat bersayapnya.</h2>
                </div>
                <span class="relation-tag">BELONGS TO MANY · MANY TO MANY</span>
            </div>
            <div class="pollinator-list">
                @foreach ($flowers as $flower)
                    <article class="pollinator-row">
                        <div class="pollinator-flower">{{ $flower->name }}</div>
                        <div class="pollinator-names">
                            @forelse ($flower->pollinators as $pollinator)
                                <span class="pollinator-pill">{{ $pollinator->name }}</span>
                            @empty
                                <span class="pollinator-note">Belum ada tamu tercatat</span>
                            @endforelse
                        </div>
                        <div class="pollinator-note">
                            {{ $flower->pollinators->pluck('pivot.relationship_note')->filter()->join(' · ') }}
                        </div>
                    </article>
                @endforeach
            </div>
        </section>
    </main>

    <footer class="closing">
        <strong>Petal &amp; Root</strong>
        <span>Herbarium digital · Merawat taman, satu bunga pada satu waktu.</span>
    </footer>
</body>
</html>
