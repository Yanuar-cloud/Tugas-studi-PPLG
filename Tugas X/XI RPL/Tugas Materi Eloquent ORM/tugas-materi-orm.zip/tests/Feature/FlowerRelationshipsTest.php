<?php

namespace Tests\Feature;

use App\Models\CareGuide;
use App\Models\Flower;
use App\Models\GardenBed;
use App\Models\Pollinator;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FlowerRelationshipsTest extends TestCase
{
    use RefreshDatabase;

    public function test_flower_models_expose_one_to_one_one_to_many_and_many_to_many_relations(): void
    {
        $bed = GardenBed::create([
            'name' => 'Petak Mentari',
            'location' => 'Timur',
            'soil_type' => 'Humus',
        ]);
        $flower = Flower::create([
            'name' => 'Dahlia Senja',
            'latin_name' => 'Dahlia pinnata',
            'color' => 'Merah muda',
            'garden_bed_id' => $bed->id,
        ]);
        $guide = CareGuide::create([
            'flower_id' => $flower->id,
            'sunlight_hours' => 6,
            'watering' => 'Siram saat tanah mulai kering.',
        ]);
        $pollinator = Pollinator::create([
            'name' => 'Lebah Madu',
            'species' => 'Apis mellifera',
            'kind' => 'Lebah',
        ]);
        $flower->pollinators()->attach($pollinator->id, [
            'relationship_note' => 'Mencari nektar.',
        ]);

        $this->assertSame($guide->id, $flower->careGuide->id);
        $this->assertSame($flower->id, $guide->flower->id);
        $this->assertSame($flower->id, $bed->flowers->first()->id);
        $this->assertSame($bed->id, $flower->gardenBed->id);
        $this->assertSame($pollinator->id, $flower->pollinators->first()->id);
        $this->assertSame('Mencari nektar.', $pollinator->flowers->first()->pivot->relationship_note);
    }

    public function test_garden_page_displays_the_seeded_relationship_data(): void
    {
        $this->seed();

        $this->get('/')
            ->assertOk()
            ->assertSee('Dahlia Senja')
            ->assertSee('Petak Mentari')
            ->assertSee('Lebah Madu')
            ->assertSee('HAS ONE')
            ->assertSee('HAS MANY')
            ->assertSee('BELONGS TO MANY');
    }
}
