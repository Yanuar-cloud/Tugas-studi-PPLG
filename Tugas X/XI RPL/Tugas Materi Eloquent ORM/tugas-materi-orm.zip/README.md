# Tugas Materi ORM — Taman Bunga

## Menjalankan aplikasi

1. Jalankan `composer install`.
2. Salin `.env.example` menjadi `.env`.
3. Jalankan `php artisan key:generate`.
4. Database SQLite berisi data taman contoh tersedia di `database/database.sqlite`.
5. Jalankan `php artisan serve`, lalu buka URL yang ditampilkan Artisan.

Untuk membuat ulang database dari migration dan seeder, jalankan `php artisan migrate:fresh --seed`. Perintah tersebut menghapus isi database saat ini.

Jalankan `php artisan test` untuk tes.
